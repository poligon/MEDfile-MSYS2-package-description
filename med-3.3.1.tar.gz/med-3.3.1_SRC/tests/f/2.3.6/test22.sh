${EXECDIR}/test22 > /dev/null 2>&1
