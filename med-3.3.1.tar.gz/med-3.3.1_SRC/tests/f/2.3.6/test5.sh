${EXECDIR}/test5 > /dev/null 2>&1
