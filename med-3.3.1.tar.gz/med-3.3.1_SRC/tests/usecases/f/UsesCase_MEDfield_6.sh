${EXECDIR}/UsesCase_MEDfield_6 > /dev/null 2>&1
